import React,{useState, useEffect} from 'react';

const Countries = (props) => {
    const [search, setSearch] = useState('');
    const [displayList, setDisplayList] = useState([]);
    let textInput = React.createRef();

    const {selectedCountry, countries, maxitems, privilege } = props;
    const [selectedDropdown, setDropdown] = useState(selectedCountry);

    let countrieslist = countries.map((loc, index) => {
    
        return <option 
                    key={'loc'+loc.id} 
                    selected = {selectedDropdown === loc.id && ' selected'}
                    value={loc.id}                    
                >{loc.country}</option>
    });

    useEffect(() => {
        let displayCountries = countries.slice(0,maxitems);
        setDisplayList(displayCountries);
        setDropdown(selectedCountry);
    },[maxitems,countries]);

    const handleChangeCountry = country => {
        let filterChange = countries.filter((item) => item.id == country.target.value);
        setDisplayList(filterChange);
        setDropdown(country.target.value)
    }

    const handleChangeSearch = () => {
        setDisplayList([]);
        setSearch(textInput.current.value);
        let filterlist = [];
        countries.map((item) => {
            if(item.country.toLowerCase().indexOf(search.toLowerCase()) !== -1){
               filterlist.push(item);
            }
        })  
        if(filterlist.length>0){
            setDisplayList(filterlist);
        }
    }
    
    const display = () => {
        props.displayAll()
    }
    const addCountry = () => {
        props.addCountry(textInput.current.value);
    }
    return(
        <>
        <select value={selectedDropdown} onChange={handleChangeCountry}>
        {countrieslist}
        </select>
        <input ref={textInput} placeholder="Search Country" value={search} onChange={handleChangeSearch} />
        <ul style={{listStyle:'none'}}>
            {displayList.length>0 ? displayList.slice(0,maxitems).map((list, index) => {
            return <li key={list.id}>{list.country}</li>
        }):
            <li>{`"${search}" not fount   `}
               {privilege && <button onClick={addCountry}>{`Add & Select`} </button>}
            </li>
        }
         </ul>
         <p><a style={{cursor:'pointer'}} onClick={display}>{`${maxitems > 10 ? '':countries.length-displayList.length} ${maxitems == 10 ? '..more': '..less'} `}</a></p>
        </>    
    )
        

}

export default Countries;