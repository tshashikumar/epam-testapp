import React, {Component} from 'react';
import Axios from 'axios';
import Countries from './components/Countries';
import './App.css';

class App extends Component { 

    constructor(props) {
      super(props);
      this.state={
        apiURL:'http://localhost:3002/countries',
        locations:[],
        filterlocs:[],
        selectedCountry:0,
        maxitems:10,
        isPrivilege:false
      }
    }
    componentDidMount(){
      let thisObj = this;
      Axios.get(this.state.apiURL)
        .then(function (response) {
           let countries = response.data;
           thisObj.setState({
              locations:countries,
              filterlocs:countries
           })
        })
        .catch(error => console.log('fetch error..',error));
    }
    displayAll(){
      this.setState({
        maxitems: this.state.maxitems == this.state.filterlocs.length? 10 : this.state.filterlocs.length}); 
    }
    addCountry(newCountry){
      let thisObj = this;      
      Axios.post(thisObj.state.apiURL,{country:newCountry})
      .then(function (response) {
          if(response.status == 201){
            let countries = response.data;
            thisObj.setState({
                locations:[...thisObj.state.locations,countries],
                filterlocs:[...thisObj.state.filterlocs,countries],
                selectedCountry:countries.id
            },() => console.log('newstate', thisObj.state))  
           }    
          
       })
       .catch(error =>  console.log(error));
    }
    render(){
      return (
      <div className="container">
          <h1>Country List</h1>
        { !this.state.isPrivilege && <p><button className="button" style={{marginLeft:'20%'}} onClick={() => this.setState({isPrivilege:true})}>Add Privilege</button></p>}
        <Countries 
          countries={this.state.filterlocs}
          selectedCountry={this.state.selectedCountry}
          maxitems={this.state.maxitems}
          displayAll={this.displayAll.bind(this)}
          privilege={this.state.isPrivilege}
          addCountry={this.addCountry.bind(this)}
          />
      </div>
      )
    }
}

export default App